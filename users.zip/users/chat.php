<?php
include_once 'header.php'; 

?>

<div class="wrapper">
        <div class="sa4d25">
            <div class="container m-6">           
                <div class="row ">
                    <div class="col-md-12">
                        <h2>Chats</h2>
                    <div class="row">
                    	<div class="col-md-8">
                    		<div class="card " id="teacher_name">
    
 </div>
                    	</div>

                    	<div class="col-md-4">
                    		<div class="card"  id="gh">
                   		<div class="card-header">
   <form class="navbar-form" role="search">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Search" name="q">
            <div class="input-group-btn">
                <button class="btn btn-primary rounded-0" type="submit"><i class="fa fa-search"></i></button>
            </div>
        </div>
        </form>
   						 </div>	
                    		<div class="card-body pre-scrollable" >

    						<div class="container-fluid dt">
    							<div class="row">
    								<?php
    								$eamil = $_SESSION['email'];
                        $querdy = mysqli_query($con,"select * from users where email='$eamil'");
                        $rodw =mysqli_fetch_array($querdy);
                    $tid =$rodw['id'];
                                    $query = mysqli_query($con,"SELECT u.* FROM `chat` join users as u on std_id =u.id where t_id ='$tid' and role = 'student' and status='Approve' group by std_id");
    								while($row = mysqli_fetch_array($query)){
    									?>
    								<div class="col-md-12 col-sm-12 col-lg-12 mt-3">
    								<a href="javascript:void();" class="chat" id="<?=$row['id']?>" style="text-decoration: none; color:black;" >	
    								<img alt="" class="img-circle medium-image float-left ml-n4 mt-n3" src="../admin/images/tutor/<?=$row['profilepic']?>"><h2 class="float-left mt-n1"><?=$row['name']?></h2>
    								<span class="float-right"><?=$row['log_in']?></span>
    								</a>
    								</div>
    								<?php
    							}?>

    						</div>
							</div> 
    
                    	</div>
                    </div>
                        
                    </div>
                  
                </div>
            </div>
        </div>
      
  

<?php
include_once 'footer.php';

?>
<script>

    $(function(){
        $(".chat").click(function(){

            var postid = $(this).attr("id");
              $.ajax({
                type:'POST',
                url:'get_student_name.php',
                data:{id:postid},
                success:function(data){
                 
                      $("#teacher_name").html(data);
                     
                }

            });

        });
    });
     $(document).ready(function(){
		 

        setInterval(function() {
            $(".dt").load("callback.php");
        }, 10000);
        
    });
    

</script>
