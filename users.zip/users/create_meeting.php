<?php
include_once 'header.php'; ?>
<div class="wrapper">
        <div class="sa4d25">
            <div class="container-fluid">           
                <div class="row">
                    <div class="col-xl-12 col-lg-12">
                        <div class="section3125">
                            <div class="live1452">
                               <div id="jitsi-container">
                               </div>
                            <div class="user_dt5">
                                <div class="user_dt_left">
                                        <div class="user_cntnt">
                                            <button id='btnCreateMeetingLink' type="button" class="btn1542">Create Meeting</button>
                        <a id='meetingid' href="#"></a>
                        <input type="text" id="link" value="" hidden>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>                          
                    </div>
                   <div class="col-md-12">
                      <table class="table table-bordered  table-sm">
                        <thead>
                            <tr>
                             <th>Include</th>
                             <th>Student name</th>
                             <th>Picture</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

        $q=mysqli_query($con,"select * from users where email='$email'");
        $res = mysqli_fetch_array($q);
        $t_id = $res['id'];
                $query=mysqli_query($con,"select s.* FROM users as s , booked as b where b.tutor_id = '$t_id' and s.id=b.std_id and DATE(b_date) = CURRENT_DATE()");
        while($row = mysqli_fetch_array($query))
        {
            ?>
                            <tr>
                                <td>
                                <input onclick="getarray(this.value)" id="check" type="checkbox" value="<?=$row['id']?>">
                              <input type="hidden" value="<?=$t_id?>" id="t_id"/>
                               </td>
                                <td><?=$row['name']?></td>
                                <td><img src="../admin/images/tutor/<?php echo $row['profilepic']?>" width="70" height="70" alt="img-thumbnail"  class="img-thumbnail" style="border-radius: 50%;">
</td>
                            </tr>
                            <?php
                        }
                        ?>
                        </tbody>

                      </table>
                   </div>
                    <div class="col-md-12">
                        <div class="section3125 mb-15 mt-20">
                            <h4 class="item_title">Live Streams</h4>
                            <a href="live_streams.html" class="see150">See all</a>
                            <div class="la5lo1">
                                <div class="owl-carousel live_stream owl-theme owl-loaded owl-drag">
                                     
                                <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1912px;"><div class="owl-item active" style="width: 202.4px; margin-right: 10px;"><div class="item">
                                        <div class="stream_1">
                                            <a href="live_output.html" class="stream_bg">
                                                <img src="images/left-imgs/img-1.jpg" alt="">
                                                <h4>John Doe</h4>
                                                <p>live<span></span></p>
                                            </a>
                                        </div>
                                    </div></div><div class="owl-item active" style="width: 202.4px; margin-right: 10px;"><div class="item">
                                        <div class="stream_1">
                                            <a href="live_output.html" class="stream_bg">
                                                <img src="images/left-imgs/img-2.jpg" alt="">
                                                <h4>Jassica</h4>
                                                <p>live<span></span></p>
                                            </a>
                                        </div>
                                    </div></div><div class="owl-item active" style="width: 202.4px; margin-right: 10px;"><div class="item">
                                        <div class="stream_1">
                                            <a href="live_output.html" class="stream_bg">
                                                <img src="images/left-imgs/img-9.jpg" alt="">
                                                <h4>Edututs+</h4>
                                                <p>live<span></span></p>
                                            </a>
                                        </div>
                                    </div></div><div class="owl-item active" style="width: 202.4px; margin-right: 10px;"><div class="item">
                                        <div class="stream_1">
                                            <a href="live_output.html" class="stream_bg">
                                                <img src="images/left-imgs/img-3.jpg" alt="">
                                                <h4>Joginder Singh</h4>
                                                <p>live<span></span></p>
                                            </a>
                                        </div>
                                    </div></div><div class="owl-item active" style="width: 202.4px; margin-right: 10px;"><div class="item">
                                        <div class="stream_1">
                                            <a href="live_output.html" class="stream_bg">
                                                <img src="images/left-imgs/img-4.jpg" alt="">
                                                <h4>Zoena</h4>
                                                <p>live<span></span></p>
                                            </a>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 202.4px; margin-right: 10px;"><div class="item">
                                        <div class="stream_1">
                                            <a href="live_output.html" class="stream_bg">
                                                <img src="images/left-imgs/img-5.jpg" alt="">
                                                <h4>Albert Dua</h4>
                                                <p>live<span></span></p>
                                            </a>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 202.4px; margin-right: 10px;"><div class="item">
                                        <div class="stream_1">
                                            <a href="live_output.html" class="stream_bg">
                                                <img src="images/left-imgs/img-6.jpg" alt="">
                                                <h4>Ridhima</h4>
                                                <p>live<span></span></p>
                                            </a>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 202.4px; margin-right: 10px;"><div class="item">
                                        <div class="stream_1">
                                            <a href="live_output.html" class="stream_bg">
                                                <img src="images/left-imgs/img-7.jpg" alt="">
                                                <h4>Amritpal</h4>
                                                <p>live<span></span></p>
                                            </a>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 202.4px; margin-right: 10px;"><div class="item">
                                        <div class="stream_1">
                                            <a href="live_output.html" class="stream_bg">
                                                <img src="images/left-imgs/img-8.jpg" alt="">
                                                <h4>Jimmy</h4>
                                                <p>live<span></span></p>
                                            </a>
                                        </div>
                                    </div></div></div></div><div class="owl-nav"><button type="button" role="presentation" class="owl-prev disabled"><i class="uil uil-angle-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="uil uil-angle-right"></i></button></div><div class="owl-dots disabled"></div></div>
                            </div>
                        </div>
                    </div>                  
                </div>
            </div>
        </div>
      
    

<?php
include_once 'footer.php';?>

        <!-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> -->
        <script src="js/external_api.js"></script>
        <script>

        var link='';
        var t_id='';
            $(function(){

            $('#btnCreateMeetingLink').on('click',function(){
                   var mul = window.location.origin + "/users/meeting.php?mid=" +  (new Date()).getTime();
                   var mul2 = window.location.origin + "/student/meeting.php?mid=" +  (new Date()).getTime();
                   $('#meetingid').attr('href',mul).text(mul);
                   $('#link').val(mul2);
                 
                });
            });
            function getarray(id,link,t_id){
    
            //let sendid=id;
            t_id =$("#t_id").val();
             link=$("#link").val();
            
                
                
                $.ajax({
                    type: "POST",
                    url: "/users/linkwork.php",
                    data:{id:id,share:link,tid:t_id},
                    success:(data)=>{
            
                         data

                    },
                    error:(err)=>{
                        alert(err)
                    }
                });
              

            }
        </script>
    