<?php
session_start();
  $id=$_REQUEST['id'];
  $share= $_REQUEST['share'];
 $tutor_id= $_REQUEST['tid'];
  include_once '../datatacle/connect.php';

   $checkEntries=mysqli_query($con,"select * from share");
    $q1=mysqli_query($con,"select * from share where tutor_id='$tutor_id' and std_id ='$id' and DATE(share_date) = CURRENT_DATE()");
$sdk=mysqli_num_rows($q1);
    if ($sdk > 0) {
       echo "Link Is Already Share To Student!";
    }
    elseif(mysqli_num_rows($checkEntries) == 0){
 mysqli_query($con,"INSERT INTO `share`(`std_id`, `tutor_id`,share_link) VALUES ('$id','$tutor_id','$share')");
 }
 else{
 mysqli_query($con,"INSERT INTO `share`(`std_id`, `tutor_id`,share_link) VALUES ('$id','$tutor_id','$share')");
 }
 
// if(isset($_SESSION['title'])){ 
//   $item_array_id=array_column($_SESSION['title'],'p_id');
//  $product_id=$id;
//  if(in_array($product_id,$item_array_id)){
//    echo 'Already Added';
//  }
// else{
//   $count=count($_SESSION['title']);
// $item=["p_id"=>$id,
// "share"=>$share
// ];
//  $_SESSION['title'][$count]=$item;



// }
// }
// else{
//   $item=["p_id"=>$id,
//   "share"=>$share
// ];
//  $_SESSION['title'][0]= $item;
//  // print_r($_SESSION['title']);
// }
//$_SESSION['d'].=$_SESSION['title'];
?>
