<?php
require_once 'vendor/autoload.php';
require_once "class-db.php";
 
define('CLIENT_ID', 'IFHJIdFrRJqFsQv7mgQh1g');
define('CLIENT_SECRET', '358gFdjXIflIdPa4GimfiyfDIVl4uJBq');
define('REDIRECT_URI', 'http://6369986c1724.ngrok.io/students/callback.php');?>