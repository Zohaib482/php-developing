<div class="row">
                                    <?php
                                    session_start();
                                    include_once '../datatacle/connect.php';
                                    $eamil = $_SESSION['email'];
$querdy = mysqli_query($con,"select * from users where email='$eamil'");
$rodw =mysqli_fetch_array($querdy);
$tid =$rodw['id'];
                                    $query = mysqli_query($con,"SELECT u.* FROM `chat` join users as u on std_id =u.id where t_id ='$tid' and role = 'student' and status='Approve' group by std_id");
                                    while($row = mysqli_fetch_array($query)){
                                        ?>
                                    <div class="col-md-12 col-sm-12 col-lg-12 mt-3">
                                    <a href="javascript:void();" class="chat" id="<?=$row['id']?>" style="text-decoration: none; color:black;" >    
                                    <img alt="" class="img-circle medium-image float-left ml-n4 mt-n3" src="../admin/images/tutor/<?=$row['profilepic']?>"><h2 class="float-left mt-n1"><?=$row['name']?></h2>
                                    <span class="float-right"><?=$row['log_in']?></span>
                                    </a>
                                    </div>
                                    <?php
                                }?>

                            </div>
<script src="js/jquery-3.js"></script>
<script src="js/jquery.ajaxy.min.js"></script>                            
<script>
    $(function(){
        $(".chat").click(function(){

            var postid = $(this).attr("id");
              $.ajax({
                type:'POST',
                url:'get_student_name.php',
                data:{id:postid},
                success:function(data){
                 
                      $("#teacher_name").html(data);
                     
                }

            });

        });
    });
</script>