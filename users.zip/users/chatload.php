<?php
include_once "../datatacle/connect.php";
$output1='';
$stdid = $_REQUEST['stdid'];
$rowtid =$_REQUEST['tid'];
$sel_msg ="select * from chat where(sender_id='$stdid' and receiver_id='$rowtid') or (receiver_id='$stdid' and sender_id='$rowtid')";
                  $run_msg=mysqli_query($con,$sel_msg);
                 
                  while( $row1 =mysqli_fetch_array($run_msg)){
		 $sender=$row1["sender_id"];
                      $recevier=$row1["receiver_id"];
                      $content=$row1["msg"];
                      $msg_date = $row1["datetimed"];
       if($stdid == $sender and $rowtid == $recevier){
    	$df=mysqli_query($con,"select u.* from chat join users as u on std_id = u.id");
    	$dr = mysqli_fetch_array($df);
    	$tname =$dr['name'];
    	$tpic = $dr['profilepic'];
    	$output1.='<div class="message info">
                            <img alt="" class="img-circle medium-image" src="../admin/images/tutor/'.$tpic.'">

                            <div class="message-body">
                                <div class="message-info">
                                    <h4>'.$tname.'</h4>
                                    <h5> <i class="fa fa-clock-o"></i>'.date('h:i a', strtotime($msg_date)).'</h5>
                                </div>
                                <hr>
                                <div class="message-text">
                                   '.$content.'
                                </div>
                            </div>
                            <br>
                        </div>';

}
 elseif( $stdid == $recevier and $rowtid == $sender){
 $df1=mysqli_query($con,"select u.* from chat join users as u on t_id = u.id");
    	$dr1 = mysqli_fetch_array($df1);
    	$sname =$dr1['name'];
    	$spic = $dr1['profilepic'];
                      $output1.='<div class="message my-message">
                            <img alt="" class="img-circle medium-image" src="../admin/images/tutor/'.$spic.'">

                            <div class="message-body">
                                <div class="message-body-inner">
                                    <div class="message-info">
                                        <h4>'.$sname.'</h4>
                                        <h5> <i class="fa fa-clock-o"></i>'.date('h:i a', strtotime($msg_date)).'</h5>
                                    </div>
                                    <hr>
                                    <div class="message-text">
                                     '.$content.'
                                    </div>
                                </div>
                            </div>
                            <br>
                        </div>';
                       

}

}
echo $output1;
?>