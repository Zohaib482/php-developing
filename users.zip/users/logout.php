<?php

session_start();
include_once '../datatacle/connect.php';
$email = $_SESSION['email'];
mysqli_query($con,"UPDATE `users` SET log_in='Offline' WHERE email ='$email'");
$query = mysqli_query($con,"select * from users where email='$email'");
$res = mysqli_fetch_array($query);
$tid= $res['id'];
$query2= mysqli_query($con,"DELETE FROM `share` WHERE tutor_id ='$tid'");
session_destroy();
header('location:../index.php')

?>