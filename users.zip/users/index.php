﻿<?php

include_once 'header.php';

	?><!-- Body Start -->
<div class="wrapper _bg4586">
		<div class="_216b01">
			<div class="container-fluid">			
				<div class="row justify-content-md-center">
					<div class="col-md-10">
						<div class="section3125 rpt145">							
							<div class="row">
							<?php
							$query=mysqli_query($con, "select * from users where email ='$email'");
							while($row=mysqli_fetch_array($query)){?>						
								<div class="col-lg-7">
									<a href="#" class="_216b22">										
										<span><i class="uil uil-cog"></i></span>Setting
									</a>
									<div class="dp_dt150">						
										<div class="img148">
										<img src="../admin/images/tutor/<?=$row['profilepic'];?>" alt="">										
										</div>
										<div class="prfledt1">
											<h2><?=$row['name'];?></h2>
											<span><?=$row['email'];?></span>
										</div>										
									</div>
									<ul class="_ttl120">
										<li>
											<div class="_ttl121">
												<div class="_ttl122">Enroll Students</div>
												<div class="_ttl123"><?=$row['enroll'];?></div>
											</div>
										</li>
										<li>
											<div class="_ttl121">
												<div class="_ttl122">Courses</div>
												<div class="_ttl123">8</div>
											</div>
										</li>
										<li>
											<div class="_ttl121">
												<div class="_ttl122">Reviews</div>
												<div class="_ttl123">11K</div>
											</div>
										</li>
										<li>
											<div class="_ttl121">
												<div class="_ttl122">Subscriptions</div>
												<div class="_ttl123">452K</div>
											</div>
										</li>
									</ul>
									
								</div>
								<div class="col-lg-5">
									
									
									<ul class="_bty149">
																		
										<li><button class="msg125 btn500" onclick="window.location.href = '#';">Edit</button></li>								
									</ul>
									<br>
									 <div align="right" style="color:white;">
        <i class="fa fa-star fa-2x" data-index="0"></i>
        <i class="fa fa-star fa-2x" data-index="1"></i>
        <i class="fa fa-star fa-2x" data-index="2"></i>
        <i class="fa fa-star fa-2x" data-index="3"></i>
        <i class="fa fa-star fa-2x" data-index="4"></i>
        <br><br>
        <p>Average rating:<span><?php echo round($avg,2) ?></span></p>
    </div>
								</div>												
								<?php }?>	
							</div>							
						</div>							
					</div>															
				</div>
			</div>
		</div>
		<div class="_215b15">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-12">						
						<div class="course_tabs">
							<nav>
								<div class="nav nav-tabs tab_crse" id="nav-tab" role="tablist">
									<a class="nav-item nav-link active" id="nav-schedule-tab" data-toggle="tab" href="#nav-schedule" role="tab" aria-selected="true">Schedule</a>
									<a class="nav-item nav-link" id="nav-courses-tab" data-toggle="tab" href="#nav-courses" role="tab" aria-selected="false">Courses</a>
									<a class="nav-item nav-link" id="nav-purchased-tab" data-toggle="tab" href="#nav-purchased" role="tab" aria-selected="false">Purchased</a>
									<a class="nav-item nav-link" id="nav-reviews-tab" data-toggle="tab" href="#nav-reviews" role="tab" aria-selected="false">Discussion</a>
									<a class="nav-item nav-link" id="nav-subscriptions-tab" data-toggle="tab" href="#nav-subscriptions" role="tab" aria-selected="false">Subscriptions</a>
								</div>
							</nav>						
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="_215b17">
			<div class="container-fluid">
				<div class="row">
				<div class="col-lg-12">
					<div class="course_tab_content">
						<div class="tab-content" id="nav-tabContent">
								<div class="tab-pane fade show active" id="nav-schedule" role="tabpanel">
									<div class="_htg451">
										<div class="_htg452">
											<h3>Class Schedule</h3>
											<table class="table table-hover table-inverse">
												<thead class="text-capitalize text-center font-weight-bold table-danger">
													<tr>
														<th>Days</th>
														<th>Timings</th>
														<th>Subjects</th>
														<th>Tutors Name</th>
													</tr>
												</thead>
												<tbody  class="text-capitalize text-center">
													<tr>
														<td>Monday</td>
														<td>4-6 PM</td>
														<td>English</td>
														<td>Ali</td>
													</tr>
												</tbody>
											</table>
										</div>																	
									</div>							
								</div>
								<div class="tab-pane fade" id="nav-courses" role="tabpanel">
									<div class="crse_content">
										<h3>My courses (8)</h3>
										<div class="_14d25">
											<div class="row">
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="fcrse_img">
															<img src="images/courses/img-1.jpg" alt="">
															<div class="course-overlay">
																<div class="badge_seller">Bestseller</div>
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>4.5
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	25 hours
																</div>
															</div>
														</a>
														<div class="fcrse_content">
															<div class="eps_dots more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-share-alt"></i>Share</span>
																	<span><i class="uil uil-edit-alt"></i>Edit</span>
																</div>																											
															</div>
															<div class="vdtodt">
																<span class="vdt14">109k views</span>
																<span class="vdt14">15 days ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s">Complete Python Bootcamp: Go from zero to hero in Python 3</a>
															<a href="#" class="crse-cate">Web Development | Python</a>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">John Doe</a></p>
																<div class="prce142">$10</div>
															</div>
														</div>
													</div>	
												</div>
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="fcrse_img">
															<img src="images/courses/img-2.jpg" alt="">
															<div class="course-overlay">
																<div class="badge_seller">Bestseller</div>
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>4.5
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	28 hours
																</div>
															</div>
														</a>
														<div class="fcrse_content">
															<div class="eps_dots more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-share-alt"></i>Share</span>
																	<span><i class="uil uil-edit-alt"></i>Edit</span>
																</div>																									
															</div>
															<div class="vdtodt">
																<span class="vdt14">5M views</span>
																<span class="vdt14">15 days ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s">The Complete JavaScript Course 2020: Build Real Projects!</a>
															<a href="#" class="crse-cate">Development | JavaScript</a>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">John Doe</a></p>
																<div class="prce142">$5</div>
															</div>
														</div>
													</div>
												</div>
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="fcrse_img">
															<img src="images/courses/img-20.jpg" alt="">
															<div class="course-overlay">
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>5.0
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	21 hours
																</div>
															</div>
														</a>
														<div class="fcrse_content">
															<div class="eps_dots more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-share-alt"></i>Share</span>
																	<span><i class="uil uil-edit-alt"></i>Edit</span>
																</div>																										
															</div>
															<div class="vdtodt">
																<span class="vdt14">200 Views</span>
																<span class="vdt14">4 days ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s">WordPress Development - Themes, Plugins &amp; Gutenberg</a>
															<a href="#" class="crse-cate">Design | Wordpress</a>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">John Doe</a></p>
																<div class="prce142">$14</div>
															</div>
														</div>
													</div>
												</div>
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="fcrse_img">
															<img src="images/courses/img-4.jpg" alt="">
															<div class="course-overlay">
																<div class="badge_seller">Bestseller</div>
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>5.0
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	1 hour
																</div>
															</div>
														</a>
														<div class="fcrse_content">
															<div class="eps_dots more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-share-alt"></i>Share</span>
																	<span><i class="uil uil-edit-alt"></i>Edit</span>
																</div>																										
															</div>
															<div class="vdtodt">
																<span class="vdt14">153k views</span>
																<span class="vdt14">3 months ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s">The Complete Digital Marketing Course - 12 Courses in 1</a>
															<a href="#" class="crse-cate">Digital Marketing | Marketing</a>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">John Doe</a></p>
																<div class="prce142">$12</div>
															</div>
														</div>
													</div>
												</div>
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="fcrse_img">
															<img src="images/courses/img-13.jpg" alt="">
															<div class="course-overlay">
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	30 hours
																</div>
															</div>
														</a>
														<div class="fcrse_content">
															<div class="eps_dots more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-share-alt"></i>Share</span>
																	<span><i class="uil uil-edit-alt"></i>Edit</span>
																</div>																										
															</div>
															<div class="vdtodt">
																<span class="vdt14">20 Views</span>
																<span class="vdt14">1 day ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s">The Complete Node.js Developer Course (3rd Edition)</a>
															<a href="#" class="crse-cate">Development | Node.js</a>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">John Doe</a></p>
																<div class="prce142">$3</div>
															</div>
														</div>
													</div>
												</div>
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="fcrse_img">
															<img src="images/courses/img-7.jpg" alt="">
															<div class="course-overlay">
																<div class="badge_seller">Bestseller</div>
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>5.0
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	5.4 hours
																</div>
															</div>
														</a>
														<div class="fcrse_content">
															<div class="eps_dots more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-share-alt"></i>Share</span>
																	<span><i class="uil uil-edit-alt"></i>Edit</span>
																</div>																										
															</div>
															<div class="vdtodt">
																<span class="vdt14">109k views</span>
																<span class="vdt14">15 days ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s">WordPress for Beginners: Create a Website Step by Step</a>
															<a href="#" class="crse-cate">Design | Wordpress</a>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">John Doe</a></p>
																<div class="prce142">$18</div>
															</div>
														</div>
													</div>
												</div>												
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="fcrse_img">
															<img src="images/courses/img-8.jpg" alt="">
															<div class="course-overlay">
																<div class="badge_seller">Bestseller</div>
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>4.0
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	23 hours
																</div>
															</div>
														</a>
														<div class="fcrse_content">
															<div class="eps_dots more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-share-alt"></i>Share</span>
																	<span><i class="uil uil-edit-alt"></i>Edit</span>
																</div>																										
															</div>
															<div class="vdtodt">
																<span class="vdt14">196k views</span>
																<span class="vdt14">1 month ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s">CSS - The Complete Guide 2020 (incl. Flexbox, Grid &amp; Sass)</a>
															<a href="#" class="crse-cate">Design | CSS</a>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">John Doe</a></p>
																<div class="prce142">$10</div>
															</div>
														</div>
													</div>
												</div>
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="fcrse_img">
															<img src="images/courses/img-16.jpg" alt="">
															<div class="course-overlay">
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	22 hours
																</div>
															</div>
														</a>
														<div class="fcrse_content">
															<div class="eps_dots more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-share-alt"></i>Share</span>
																	<span><i class="uil uil-edit-alt"></i>Edit</span>
																</div>																									
															</div>
															<div class="vdtodt">
																<span class="vdt14">11 Views</span>
																<span class="vdt14">5 Days ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s">Vue JS 2 - The Complete Guide (incl. Vue Router &amp; Vuex)</a>
															<a href="#" class="crse-cate">Development | Vue JS</a>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">John Doe</a></p>
																<div class="prce142">$10</div>
															</div>
														</div>
													</div>
												</div>
											</div>		
										</div>		
									</div>
								</div>
								<div class="tab-pane fade show" id="nav-purchased" role="tabpanel">
									<div class="_htg451">
										<div class="_htg452">
											<h3>Purchased Courses</h3>
											<div class="row">
												<div class="col-md-9">
													<div class="fcrse_1 mt-20">
														<a href="course_detail_view.html" class="hf_img">
															<img src="images/courses/img-1.jpg" alt="">
															<div class="course-overlay">
																<div class="badge_seller">Bestseller</div>
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>4.5
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	25 hours
																</div>
															</div>
														</a>
														<div class="hs_content">
															<div class="eps_dots eps_dots10 more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-download-alt"></i>Download</span>															
																	<span><i class="uil uil-trash-alt"></i>Delete</span>															
																</div>																											
															</div>
															<div class="vdtodt">
																<span class="vdt14">109k views</span>
																<span class="vdt14">15 days ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s title900">Complete Python Bootcamp: Go from zero to hero in Python 3</a>
															<a href="#" class="crse-cate">Web Development | Python</a>
															<div class="purchased_badge">Purchased</div>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">John Doe</a></p>
																<div class="prce142">$10</div>
															</div>
														</div>
													</div>
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="hf_img">
															<img src="images/courses/img-2.jpg" alt="">
															<div class="course-overlay">
																<div class="badge_seller">Bestseller</div>
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>4.5
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	28 hours
																</div>
															</div>
														</a>
														<div class="hs_content">
															<div class="eps_dots eps_dots10 more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-download-alt"></i>Download</span>															
																	<span><i class="uil uil-trash-alt"></i>Delete</span>															
																</div>																											
															</div>
															<div class="vdtodt">
																<span class="vdt14">5M views</span>
																<span class="vdt14">15 days ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s title900">The Complete JavaScript Course 2020: Build Real Projects!</a>
															<a href="#" class="crse-cate">Development | JavaScript</a>
															<div class="purchased_badge">Purchased</div>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">Jassica William</a></p>
																<div class="prce142">$5</div>
															</div>
														</div>
													</div>
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="hf_img">
															<img src="images/courses/img-3.jpg" alt="">
															<div class="course-overlay">
																<div class="badge_seller">Bestseller</div>
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>4.5
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	12 hours
																</div>
															</div>
														</a>
														<div class="hs_content">
															<div class="eps_dots eps_dots10 more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-download-alt"></i>Download</span>															
																	<span><i class="uil uil-trash-alt"></i>Delete</span>															
																</div>																											
															</div>
															<div class="vdtodt">
																<span class="vdt14">1M views</span>
																<span class="vdt14">18 days ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s title900">Beginning C++ Programming - From Beginner to Beyond</a>
															<a href="#" class="crse-cate">Development | C++</a>
															<div class="purchased_badge">Purchased</div>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">Joginder Singh</a></p>
																<div class="prce142">$13</div>
															</div>
														</div>
													</div>
													<div class="fcrse_1 mt-30">
														<a href="course_detail_view.html" class="hf_img">
															<img src="images/courses/img-4.jpg" alt="">
															<div class="course-overlay">
																<div class="badge_seller">Bestseller</div>
																<div class="crse_reviews">
																	<i class="uil uil-star"></i>5.0
																</div>
																<span class="play_btn1"><i class="uil uil-play"></i></span>
																<div class="crse_timer">
																	1 hours
																</div>
															</div>
														</a>
														<div class="hs_content">
															<div class="eps_dots eps_dots10 more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class="uil uil-download-alt"></i>Download</span>															
																	<span><i class="uil uil-trash-alt"></i>Delete</span>															
																</div>																											
															</div>
															<div class="vdtodt">
																<span class="vdt14">153k views</span>
																<span class="vdt14">3 months ago</span>
															</div>
															<a href="course_detail_view.html" class="crse14s title900">The Complete Digital Marketing Course - 12 Courses in 1</a>
															<a href="#" class="crse-cate">Digital Marketing | Marketing</a>
															<div class="purchased_badge">Purchased</div>
															<div class="auth1lnkprce">
																<p class="cr1fot">By <a href="#">Poonam Verma</a></p>
																<div class="prce142">$12</div>
															</div>
														</div>
													</div>
												</div>									
											</div>
										</div>																	
									</div>							
								</div>
								<div class="tab-pane fade" id="nav-reviews" role="tabpanel">
									<div class="student_reviews">
										<div class="row">
											<div class="col-lg-12">
												<div class="review_right">
													<div class="review_right_heading">
														<h3>Discussions</h3>
													</div>
												</div>
												<div class="cmmnt_1526">
													<div class="cmnt_group">
														<div class="img160">
															<img src="images/hd_dp.jpg" alt="">									
														</div>
														<textarea class="_cmnt001" placeholder="Add a public comment"></textarea>
													</div>
													<button class="cmnt-btn" type="submit">Comment</button>
												</div>
												<div class="review_all120">
													<div class="review_item">
														<div class="review_usr_dt">
															<img src="images/left-imgs/img-1.jpg" alt="">
															<div class="rv1458">
																<h4 class="tutor_name1">John Doe</h4>
																<span class="time_145">2 hour ago</span>
															</div>
															<div class="eps_dots more_dropdown">
																<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																<div class="dropdown-content">
																	<span><i class='uil uil-comment-alt-edit'></i>Edit</span>
																	<span><i class='uil uil-trash-alt'></i>Delete</span>
																</div>																											
															</div>
														</div>
														<p class="rvds10">Nam gravida elit a velit rutrum, eget dapibus ex elementum. Interdum et malesuada fames ac ante ipsum primis in faucibus. Fusce lacinia, nunc sit amet tincidunt venenatis.</p>
														<div class="rpt101">
															<a href="#" class="report155"><i class='uil uil-thumbs-up'></i> 10</a>
															<a href="#" class="report155"><i class='uil uil-thumbs-down'></i> 1</a>
															<a href="#" class="report155"><i class='uil uil-heart'></i></a>
															<a href="#" class="report155 ml-3">Reply</a>
														</div>
													</div>
													<div class="review_reply">
														<div class="review_item">
															<div class="review_usr_dt">
																<img src="images/left-imgs/img-3.jpg" alt="">
																<div class="rv1458">
																	<h4 class="tutor_name1">Rock Doe</h4>
																	<span class="time_145">1 hour ago</span>
																</div>
																<div class="eps_dots more_dropdown">
																	<a href="#"><i class="uil uil-ellipsis-v"></i></a>
																	<div class="dropdown-content">
																		<span><i class='uil uil-trash-alt'></i>Delete</span>
																	</div>																											
																</div>
															</div>
															<p class="rvds10">Fusce lacinia, nunc sit amet tincidunt venenatis.</p>
															<div class="rpt101">
																<a href="#" class="report155"><i class='uil uil-thumbs-up'></i> 4</a>
																<a href="#" class="report155"><i class='uil uil-thumbs-down'></i> 2</a>
																<a href="#" class="report155"><i class='uil uil-heart'></i></a>
																<a href="#" class="report155 ml-3">Reply</a>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="tab-pane fade show" id="nav-subscriptions" role="tabpanel">
									<div class="_htg451">
										<div class="_htg452">
											<h3>Subscriptions</h3>
											<div class="row">
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<div class="tutor_img">
															<a href="#"><img src="images/left-imgs/img-1.jpg" alt=""></a>												
														</div>
														<div class="tutor_content_dt">
															<div class="tutor150">
																<a href="#" class="tutor_name">John Doe</a>
																<div class="mef78" title="Verify">
																	<i class="uil uil-check-circle"></i>
																</div>
															</div>
															<div class="tutor_cate">Wordpress &amp; Plugin Tutor</div>
															<ul class="tutor_social_links">
																<li><button class="sbbc145">Subscribed</button></li>
																<li><button class="sbbc146"><i class="uil uil-bell"></i></button></li>
															</ul>
															<div class="tut1250">
																<span class="vdt15">100K Students</span>
																<span class="vdt15">15 Courses</span>
															</div>
														</div>
													</div>										
												</div>
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<div class="tutor_img">
															<a href="#"><img src="images/left-imgs/img-2.jpg" alt=""></a>											
														</div>
														<div class="tutor_content_dt">
															<div class="tutor150">
																<a href="#" class="tutor_name">Kerstin Cable</a>
																<div class="mef78" title="Verify">
																	<i class="uil uil-check-circle"></i>
																</div>
															</div>
															<div class="tutor_cate">Language Learning Coach, Writer, Online Tutor</div>
															<ul class="tutor_social_links">
																<li><button class="sbbc145">Subscribed</button></li>
																<li><button class="sbbc146"><i class="uil uil-bell"></i></button></li>
															</ul>
															<div class="tut1250">
																<span class="vdt15">14K Students</span>
																<span class="vdt15">11 Courses</span>
															</div>
														</div>
													</div>										
												</div>
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<div class="tutor_img">
															<a href="#"><img src="images/left-imgs/img-3.jpg" alt=""></a>												
														</div>
														<div class="tutor_content_dt">
															<div class="tutor150">
																<a href="#" class="tutor_name">Jose Portilla</a>
																<div class="mef78" title="Verify">
																	<i class="uil uil-check-circle"></i>
																</div>
															</div>
															<div class="tutor_cate">Head of Data Science, Pierian Data Inc.</div>
															<ul class="tutor_social_links">
																<li><button class="sbbc145">Subscribed</button></li>
																<li><button class="sbbc146"><i class="uil uil-bell"></i></button></li>
															</ul>
															<div class="tut1250">
																<span class="vdt15">1M Students</span>
																<span class="vdt15">25 Courses</span>
															</div>
														</div>
													</div>										
												</div>
												<div class="col-lg-3 col-md-4">
													<div class="fcrse_1 mt-30">
														<div class="tutor_img">
															<a href="#"><img src="images/left-imgs/img-3.jpg" alt=""></a>												
														</div>
														<div class="tutor_content_dt">
															<div class="tutor150">
																<a href="#" class="tutor_name">Jose Portilla</a>
																<div class="mef78" title="Verify">
																	<i class="uil uil-check-circle"></i>
																</div>
															</div>
															<div class="tutor_cate">Head of Data Science, Pierian Data Inc.</div>
															<ul class="tutor_social_links">
																<li><button class="sbbc145">Subscribed</button></li>
																<li><button class="sbbc146"><i class="uil uil-bell"></i></button></li>
															</ul>
															<div class="tut1250">
																<span class="vdt15">1M Students</span>
																<span class="vdt15">25 Courses</span>
															</div>
														</div>
													</div>										
												</div>
											</div>				
										</div>																	
									</div>							
								</div>
						</div>
						</div>
					</div>
				</div>
			</div>
			</div>
		
	<?php
include_once 'footer.php';
if($_SESSION['check_student'] !=null) {
?>
	<script>
		window.onload=()=>{
			
		window.location="index-2.php";
	}


	</script>



	<?php
}


	?>
