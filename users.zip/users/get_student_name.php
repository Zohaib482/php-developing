<?php
session_start();
include_once "../datatacle/connect.php";
$eamil = $_SESSION['email'];
$querdy = mysqli_query($con,"select * from users where email='$eamil'");
$rodw =mysqli_fetch_array($querdy);
$stdid =$rodw['id'];
$output='';
$id = $_REQUEST['id'];
@$sms =mysqli_real_escape_string($con,$_REQUEST['sms']);
@$std_id = $_REQUEST['stdid'];
if (isset($id)) {
  
$query = mysqli_query($con,"select * from users where id ='$id' and role='student'");

$row =mysqli_fetch_array($query);
$rowtid = $row['id'];
if ($row['log_in'] == "Online") {
$output.='<div class="card-header">
      <div >
<img alt="" class="img-circle medium-image float-left" src="../admin/images/tutor/'.$row['profilepic'].'">
        <h2 style="margin-left:60px !important; margin-top:-0px !important;" class="idtec" id="'.$row['id'].'">'.$row['name'].'</h2>
        <span class="float-left mt-n3 ml-3"><i class="fa fa-circle text-success" aria-hidden="true"></i>&nbsp;'.$row['log_in'].'</span>
      </div>
    </div>
    <div class="card-body pre-scrollable" id="ifr"></div> 
    <div class="card-footer">
      <div class="container mx-3">
      <form id="forid">
        <div class="form-group">
        <div class="row">
          <div class="col-md-9 col-sm-9 col-lg-9 col-xl-9"><input type="text" class="form-control form-text sms">
          </div>
          <div class="col-md-3 col-sm-3 col-lg-3 col-xl-3"><button type="submit" class="btn1542 sendsms"><i class="fas fa-location-arrow"></i></button></div>
        </div>
      </div>
    </form>
  </div>
    </div>

<script src="js/jquery-3.js"></script>
<script src="js/jquery.ajaxy.min.js"></script> 
<script>';
if (isset($stdid) && isset($rowtid)) {
  $output.='
      function loaddata(){
      
       var stdid = '.$rowtid.';
            
            var tid = '.$stdid.';
              $.ajax({
                type:"POST",
                url:"chatload.php",
                data:{tid:tid,stdid:stdid},
                success:function(data){
                  
                     $("#ifr").html(data);
                     
                }

            });

       
    }
    
  ';
}
$output.='
   $("#forid").submit(function(e){
            e.preventDefault();
            var stdid = $(".idtec").attr("id");
            
            var sms = $(".sms").val();

              $.ajax({
                type:"POST",
                url:"get_student_name.php",
                data:{stdid:stdid,sms:sms,btnsend:"sendsms"},
                success:function(data){
                 loaddata();
                 $("#forid")[0].reset();
                      
                     
                }

            });

        });
          $(document).ready(function(){
     
      loaddata();
setInterval(function() {loaddata()}, 10000);
      });
</script>';

}
elseif ($row['log_in'] == "Offline") {
  $output.='<div class="card-header">
      <div >
<img alt="" class="img-circle medium-image float-left" src="../admin/images/tutor/'.$row['profilepic'].'">
        <h2 style="margin-left:60px !important; margin-top:-0px !important;" class="idtec" id="'.$row['id'].'">'.$row['name'].'</h2>
        <span class="float-left mt-n3 ml-3"><i class="fa fa-circle-o text-danger" aria-hidden="true"></i>&nbsp;'.$row['log_in'].'</span>
      </div>
    </div>
    <div class="card-body pre-scrollable" id="ifr"></div> 
    <div class="card-footer">
      <div class="container mx-3">
      <form id="forid">
        <div class="form-group">
        <div class="row">
          <div class="col-md-9 col-sm-9 col-lg-9 col-xl-9"><input type="text" class="form-control form-text" id="sms">
          </div>
          <div class="col-md-3 col-sm-3 col-lg-3 col-xl-3"><button type="submit" class="btn1542 sendsms"><i class="fas fa-location-arrow"></i></button></div>
        </div>
      </div>
    </form>
  </div>
    </div>

<script src="js/jquery-3.js"></script>
<script src="js/jquery.ajaxy.min.js"></script> 
<script>';
if (isset($stdid) && isset($rowtid)) {
  $output.='
      function loaddata(){
      
       var tid = '.$rowtid.';
            
            var stdid = '.$stdid.';
              $.ajax({
                type:"POST",
                url:"chatload.php",
                data:{tid:tid,stdid:stdid},
                success:function(data){
                  
                     $("#ifr").html(data);
                     
                }

            });

       
    }
    
  ';
}
$output.='
   $("#forid").submit(function(e){
            e.preventDefault();

            var stdid = $(".idtec").attr("id");
            
            var sms = $(".sms").val();

              $.ajax({
                type:"POST",
                url:"get_student_name.php",
                data:{stdid:stdid,sms:sms,btnsend:"sendsms"},
                success:function(data){
                 loaddata();
                 $("#forid")[0].reset();
                      
                     
                }

            });

        });
          $(document).ready(function(){
     
      loaddata();
setInterval(function() {loaddata()}, 10000);
      });
</script>';

}

}
if (isset($_POST['btnsend'])) {
  
$query = mysqli_query($con,"INSERT INTO `chat`(`receiver_id`, `sender_id`, `msg`,t_id,std_id) VALUES ('$std_id','$stdid','$sms','$stdid','$std_id')");

}

echo $output;
?>